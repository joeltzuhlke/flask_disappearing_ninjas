from flask import Flask, render_template, request, redirect
app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/ninja')
def ninjas():
    return render_template('ninjas.html')
@app.route('/ninja/<variable>')
def other(variable):
    if variable == "blue":
        return render_template('leonardo.html')
    elif variable == "orange":
        return render_template('michelangelo.html')
    elif variable == "red":
        return render_template('raphael.html')
    elif variable == "purple":
        return render_template('donatello.html')
    else:
        return render_template('notapril.html')





app.run(debug=True)